<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        // mengarah pada file login yang ada di folder view
        return view('login', [
            'judul' => 'login'
        ]);
    }

    public function authenticate(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        // dd('Login Berhasil');


        if (Auth::attempt($credentials)) {
            // return "Berhasil";
            $request->session()->regenerate();
            $request->session()->flash('berhasil', 'Login Berhasil !');
            if (Auth::user()->jabatan == '2') {
                return redirect()->intended('/halamanAdmin');
            } else {
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return redirect('/');
            }
        }
    }

    public function loginSiswa(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        $siswa = User::where('username', $request->username)->first();
        $nama = $siswa->file . ".pdf";
        return redirect('smartedu-master\images\raport' . $nama);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        $request->session()->flash('keluar', 'Logout Berhasil !');
        return redirect('/');
    }

    public function hapusSiswa($id)
    {
        $pemasukan = User::find($id);
        $pemasukan->delete();

        return redirect('/siswa');
    }

    public function hapusGuru($id)
    {
        $pemasukan = User::find($id);
        $pemasukan->delete();

        return redirect('/guruAdmin');
    }

    public function updateSiswa(Request $request, $id)
    {
        $siswa           = User::find($id);
        $passwordLama = $siswa->password;
        $siswa->nama    = $request->nama;
        $siswa->username  = $request->username;
        if ($request->password != null) {
            $siswa->password  = bcrypt($request->password);
        } else {
            $siswa->password =  $siswa->password;
        }
        $siswa->save();
        return redirect('/siswa');
    }
}
